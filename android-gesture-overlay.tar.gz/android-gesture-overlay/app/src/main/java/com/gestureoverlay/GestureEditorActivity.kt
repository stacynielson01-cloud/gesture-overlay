package com.gestureoverlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gestureoverlay.data.ExecutionMode
import com.gestureoverlay.data.GestureConfig
import com.gestureoverlay.data.StrokeConfig
import com.gestureoverlay.service.CoordinatePickerService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * GestureEditorActivity lets the user:
 *  - Name a button (e.g. "Bomb", "Punch", "Grab")
 *  - Pick the swipe START point by tapping the real screen
 *  - Pick the swipe END point by tapping the real screen
 *  - Choose mode: Single / Loop / Burst
 *  - Set duration (how fast the swipe moves)
 *  - Save → the button appears on the floating overlay
 */
@AndroidEntryPoint
class GestureEditorActivity : AppCompatActivity() {

    @Inject lateinit var repository: com.gestureoverlay.data.GestureConfigRepository

    // Existing config to edit, or null for new
    private var editingConfig: GestureConfig? = null

    // Picked coordinates
    private var startX = 0f
    private var startY = 0f
    private var endX   = 0f
    private var endY   = 0f
    private var startPicked = false
    private var endPicked   = false

    // Views
    private lateinit var etLabel:       EditText
    private lateinit var btnPickStart:  Button
    private lateinit var btnPickEnd:    Button
    private lateinit var tvStartCoord:  TextView
    private lateinit var tvEndCoord:    TextView
    private lateinit var spinnerMode:   Spinner
    private lateinit var seekDuration:  SeekBar
    private lateinit var tvDuration:    TextView
    private lateinit var seekInterval:  SeekBar
    private lateinit var tvInterval:    TextView
    private lateinit var seekBurst:     SeekBar
    private lateinit var tvBurst:       TextView
    private lateinit var layoutLoop:    View
    private lateinit var layoutBurst:   View
    private lateinit var btnSave:       Button
    private lateinit var btnCancel:     Button

    private var durationMs  = 200L
    private var intervalMs  = 800L
    private var burstCount  = 3
    private var selectedMode = ExecutionMode.SINGLE

    private val coordinateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val x    = intent?.getFloatExtra(CoordinatePickerService.EXTRA_X, 0f) ?: return
            val y    = intent.getFloatExtra(CoordinatePickerService.EXTRA_Y, 0f)
            val mode = intent.getStringExtra(CoordinatePickerService.EXTRA_MODE)

            // Restore our window
            window.decorView.visibility = View.VISIBLE

            if (mode == CoordinatePickerService.MODE_START) {
                startX = x; startY = y; startPicked = true
                tvStartCoord.text = "Start: (${x.toInt()}, ${y.toInt()})"
                btnPickStart.text = "Re-pick Start Point"
            } else {
                endX = x; endY = y; endPicked = true
                tvEndCoord.text = "End: (${x.toInt()}, ${y.toInt()})"
                btnPickEnd.text  = "Re-pick End Point"
            }
            updateSaveButton()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gesture_editor)

        editingConfig = intent.getParcelableExtra(EXTRA_CONFIG)
        bindViews()
        setupSpinner()
        setupSeekBars()
        setupButtons()
        prefillIfEditing()

        registerReceiver(
            coordinateReceiver,
            IntentFilter(CoordinatePickerService.ACTION_COORDINATE_PICKED),
            RECEIVER_NOT_EXPORTED
        )
    }

    override fun onDestroy() {
        unregisterReceiver(coordinateReceiver)
        super.onDestroy()
    }

    private fun bindViews() {
        etLabel      = findViewById(R.id.et_button_label)
        btnPickStart = findViewById(R.id.btn_pick_start)
        btnPickEnd   = findViewById(R.id.btn_pick_end)
        tvStartCoord = findViewById(R.id.tv_start_coord)
        tvEndCoord   = findViewById(R.id.tv_end_coord)
        spinnerMode  = findViewById(R.id.spinner_mode)
        seekDuration = findViewById(R.id.seek_duration)
        tvDuration   = findViewById(R.id.tv_duration)
        seekInterval = findViewById(R.id.seek_interval)
        tvInterval   = findViewById(R.id.tv_interval)
        seekBurst    = findViewById(R.id.seek_burst)
        tvBurst      = findViewById(R.id.tv_burst)
        layoutLoop   = findViewById(R.id.layout_loop_options)
        layoutBurst  = findViewById(R.id.layout_burst_options)
        btnSave      = findViewById(R.id.btn_save)
        btnCancel    = findViewById(R.id.btn_cancel)
    }

    private fun setupSpinner() {
        val modes = listOf("Single press", "Loop (repeating)", "Burst (rapid repeat)")
        spinnerMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        spinnerMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedMode = when (pos) {
                    1    -> ExecutionMode.LOOP
                    2    -> ExecutionMode.BURST
                    else -> ExecutionMode.SINGLE
                }
                layoutLoop.visibility  = if (selectedMode == ExecutionMode.LOOP)  View.VISIBLE else View.GONE
                layoutBurst.visibility = if (selectedMode == ExecutionMode.BURST) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun setupSeekBars() {
        // Duration: 50ms – 2000ms
        seekDuration.max = 195
        seekDuration.progress = 15 // default 200ms
        seekDuration.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                durationMs = (50 + progress * 10).toLong()
                tvDuration.text = "Swipe duration: ${durationMs}ms"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        tvDuration.text = "Swipe duration: ${durationMs}ms"

        // Loop interval: 200ms – 3000ms
        seekInterval.max = 28
        seekInterval.progress = 6 // default 800ms
        seekInterval.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                intervalMs = (200 + progress * 100).toLong()
                tvInterval.text = "Repeat every: ${intervalMs}ms"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        tvInterval.text = "Repeat every: ${intervalMs}ms"

        // Burst count: 2–20
        seekBurst.max = 18
        seekBurst.progress = 1 // default 3
        seekBurst.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                burstCount = 2 + progress
                tvBurst.text = "Burst count: $burstCount"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        tvBurst.text = "Burst count: $burstCount"
    }

    private fun setupButtons() {
        btnPickStart.setOnClickListener {
            window.decorView.visibility = View.INVISIBLE
            CoordinatePickerService.start(this, CoordinatePickerService.MODE_START)
        }

        btnPickEnd.setOnClickListener {
            window.decorView.visibility = View.INVISIBLE
            CoordinatePickerService.start(this, CoordinatePickerService.MODE_END)
        }

        btnSave.setOnClickListener { saveGesture() }
        btnCancel.setOnClickListener { finish() }

        updateSaveButton()
    }

    private fun prefillIfEditing() {
        val config = editingConfig ?: return
        etLabel.setText(config.label)

        val stroke = config.strokes.firstOrNull()
        if (stroke != null) {
            startX = stroke.startX; startY = stroke.startY; startPicked = true
            endX   = stroke.endX;   endY   = stroke.endY;   endPicked   = true
            tvStartCoord.text = "Start: (${startX.toInt()}, ${startY.toInt()})"
            tvEndCoord.text   = "End: (${endX.toInt()}, ${endY.toInt()})"
            btnPickStart.text = "Re-pick Start Point"
            btnPickEnd.text   = "Re-pick End Point"
            durationMs = stroke.durationMs
        }

        selectedMode = config.mode
        intervalMs   = config.loopIntervalMs
        burstCount   = config.burstCount

        spinnerMode.setSelection(when (config.mode) {
            ExecutionMode.LOOP  -> 1
            ExecutionMode.BURST -> 2
            else                -> 0
        })

        seekDuration.progress = ((durationMs - 50) / 10).toInt().coerceIn(0, 195)
        tvDuration.text = "Swipe duration: ${durationMs}ms"

        seekInterval.progress = ((intervalMs - 200) / 100).toInt().coerceIn(0, 28)
        tvInterval.text = "Repeat every: ${intervalMs}ms"

        seekBurst.progress = (burstCount - 2).coerceIn(0, 18)
        tvBurst.text = "Burst count: $burstCount"

        updateSaveButton()
    }

    private fun updateSaveButton() {
        btnSave.isEnabled = startPicked && endPicked
        btnSave.alpha = if (btnSave.isEnabled) 1f else 0.4f
    }

    private fun saveGesture() {
        val label = etLabel.text.toString().trim().ifEmpty { "Swipe" }

        val stroke = StrokeConfig(
            startX     = startX, startY = startY,
            endX       = endX,   endY   = endY,
            durationMs = durationMs,
            startOffsetMs = 0L
        )

        val config = (editingConfig ?: GestureConfig()).copy(
            label          = label,
            strokes        = listOf(stroke),
            mode           = selectedMode,
            loopIntervalMs = intervalMs,
            burstCount     = burstCount,
            jitterEnabled  = true,
            jitterRadiusPx = 3f,
            timingVariationEnabled = true,
            timingVariationMs      = 10L
        )

        lifecycleScope.launch {
            repository.updateGestureInActiveProfile(config)
            setResult(RESULT_OK)
            finish()
        }
    }

    companion object {
        const val EXTRA_CONFIG = "extra_gesture_config"

        fun startForNew(context: Context) {
            context.startActivity(Intent(context, GestureEditorActivity::class.java))
        }

        fun startForEdit(context: Context, config: GestureConfig) {
            context.startActivity(
                Intent(context, GestureEditorActivity::class.java)
                    .putExtra(EXTRA_CONFIG, config)
            )
        }
    }
}
