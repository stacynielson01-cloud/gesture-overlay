package com.gestureoverlay.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * CoordinatePickerService shows a full-screen transparent overlay.
 * When the user taps anywhere on screen, it captures the (x,y) coordinate
 * and broadcasts it back to the calling activity, then dismisses itself.
 *
 * Start with:
 *   CoordinatePickerService.start(context, EXTRA_MODE_START)
 * or
 *   CoordinatePickerService.start(context, EXTRA_MODE_END)
 *
 * Result is broadcast via ACTION_COORDINATE_PICKED with:
 *   EXTRA_X, EXTRA_Y, EXTRA_MODE
 */
class CoordinatePickerService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_START
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay(mode)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun showOverlay(mode: String) {
        removeOverlay()

        val label = if (mode == MODE_START) "Tap the SWIPE START point" else "Tap the SWIPE END point"
        val color  = if (mode == MODE_START) 0x99004D40.toInt() else 0x990D47A1.toInt()

        val root = FrameLayout(this)

        // Semi-transparent full screen background
        val bg = View(this).apply { setBackgroundColor(color) }
        root.addView(bg, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Instruction text
        val tv = TextView(this).apply {
            text = "$label\n\n(Tap anywhere)"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(48, 0, 48, 0)
        }
        root.addView(tv, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))

        // Cancel button at top-right
        val cancel = TextView(this).apply {
            text = "✕ Cancel"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(32, 32, 32, 32)
        }
        root.addView(cancel, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        ))

        root.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                // Check if cancel was tapped (top-right 120x120 area)
                val isCancelArea = event.rawX > (resources.displayMetrics.widthPixels - 200) &&
                        event.rawY < 200
                if (!isCancelArea) {
                    broadcastCoordinate(mode, event.rawX, event.rawY)
                }
                stopSelf()
            }
            true
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        windowManager.addView(root, params)
        overlayView = root
    }

    private fun broadcastCoordinate(mode: String, x: Float, y: Float) {
        sendBroadcast(Intent(ACTION_COORDINATE_PICKED).apply {
            setPackage(packageName)
            putExtra(EXTRA_X, x)
            putExtra(EXTRA_Y, y)
            putExtra(EXTRA_MODE, mode)
        })
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { }
            overlayView = null
        }
    }

    companion object {
        const val ACTION_COORDINATE_PICKED = "com.gestureoverlay.COORDINATE_PICKED"
        const val EXTRA_X    = "extra_x"
        const val EXTRA_Y    = "extra_y"
        const val EXTRA_MODE = "extra_mode"
        const val MODE_START = "start"
        const val MODE_END   = "end"

        fun start(context: Context, mode: String) {
            context.startService(
                Intent(context, CoordinatePickerService::class.java)
                    .putExtra(EXTRA_MODE, mode)
            )
        }
    }
}
