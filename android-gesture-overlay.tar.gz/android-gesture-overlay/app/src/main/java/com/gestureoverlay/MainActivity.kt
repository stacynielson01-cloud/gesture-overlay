package com.gestureoverlay

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gestureoverlay.data.GestureConfig
import com.gestureoverlay.data.GestureConfigRepository
import com.gestureoverlay.data.GestureProfile
import com.gestureoverlay.service.FloatingButtonService
import com.gestureoverlay.service.GestureAccessibilityService
import com.gestureoverlay.ui.GestureAdapter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject lateinit var repository: GestureConfigRepository

    private lateinit var tvOverlayStatus:       TextView
    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var btnOverlay:            Button
    private lateinit var btnAccessibility:      Button
    private lateinit var btnStartOverlay:       Button
    private lateinit var btnStopOverlay:        Button
    private lateinit var btnAddGesture:         Button
    private lateinit var recyclerGestures:      RecyclerView
    private lateinit var adapter:               GestureAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupRecycler()
        setupClicks()
        observeProfile()
        ensureDefaultProfile()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ── Views ─────────────────────────────────────────────────────────────────

    private fun bindViews() {
        tvOverlayStatus       = findViewById(R.id.tv_overlay_status)
        tvAccessibilityStatus = findViewById(R.id.tv_accessibility_status)
        btnOverlay            = findViewById(R.id.btn_enable_overlay)
        btnAccessibility      = findViewById(R.id.btn_enable_accessibility)
        btnStartOverlay       = findViewById(R.id.btn_start_overlay)
        btnStopOverlay        = findViewById(R.id.btn_stop_overlay)
        btnAddGesture         = findViewById(R.id.btn_add_gesture)
        recyclerGestures      = findViewById(R.id.recycler_gestures)
    }

    private fun setupRecycler() {
        adapter = GestureAdapter(
            onEdit   = { config -> GestureEditorActivity.startForEdit(this, config) },
            onDelete = { config -> confirmDelete(config) }
        )
        recyclerGestures.layoutManager = LinearLayoutManager(this)
        recyclerGestures.adapter = adapter
    }

    private fun setupClicks() {
        btnOverlay.setOnClickListener {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
        }
        btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnStartOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) { btnOverlay.performClick(); return@setOnClickListener }
            FloatingButtonService.start(this)
        }
        btnStopOverlay.setOnClickListener { FloatingButtonService.stop(this) }
        btnAddGesture.setOnClickListener  { GestureEditorActivity.startForNew(this) }
    }

    // ── Status ────────────────────────────────────────────────────────────────

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val a11yOk    = GestureAccessibilityService.instance?.isConnected() == true

        tvOverlayStatus.text = if (overlayOk) getString(R.string.status_overlay_ok)
                               else            getString(R.string.status_overlay_missing)
        tvOverlayStatus.setTextColor(getColor(if (overlayOk) R.color.status_ok else R.color.status_error))

        tvAccessibilityStatus.text = if (a11yOk) getString(R.string.status_accessibility_ok)
                                     else         getString(R.string.status_accessibility_missing)
        tvAccessibilityStatus.setTextColor(getColor(if (a11yOk) R.color.status_ok else R.color.status_error))

        btnOverlay.isEnabled      = !overlayOk
        btnStartOverlay.isEnabled = overlayOk
    }

    // ── Profile observation ───────────────────────────────────────────────────

    private fun observeProfile() {
        lifecycleScope.launch {
            repository.activeProfile.collectLatest { profile ->
                adapter.submitList(profile?.gestures ?: emptyList())
            }
        }
    }

    private fun ensureDefaultProfile() {
        lifecycleScope.launch {
            if (repository.profiles.value.isEmpty()) {
                val profile = GestureProfile(name = "My Gestures")
                repository.saveProfile(profile)
                repository.setActiveProfile(profile.id)
            }
        }
    }

    private fun confirmDelete(config: GestureConfig) {
        AlertDialog.Builder(this)
            .setTitle("Delete \"${config.label}\"?")
            .setMessage("This button will be removed from the overlay.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    repository.removeGestureFromActiveProfile(config.id)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
