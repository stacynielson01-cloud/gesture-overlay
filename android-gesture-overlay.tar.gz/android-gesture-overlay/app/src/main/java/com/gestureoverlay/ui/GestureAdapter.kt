package com.gestureoverlay.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gestureoverlay.R
import com.gestureoverlay.data.ExecutionMode
import com.gestureoverlay.data.GestureConfig

class GestureAdapter(
    private val onEdit:   (GestureConfig) -> Unit,
    private val onDelete: (GestureConfig) -> Unit
) : ListAdapter<GestureConfig, GestureAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_gesture, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        private val tvLabel:  TextView    = v.findViewById(R.id.tv_gesture_label)
        private val tvCoords: TextView    = v.findViewById(R.id.tv_gesture_coords)
        private val tvMode:   TextView    = v.findViewById(R.id.tv_gesture_mode)
        private val btnEdit:  ImageButton = v.findViewById(R.id.btn_gesture_edit)
        private val btnDel:   ImageButton = v.findViewById(R.id.btn_gesture_delete)

        fun bind(config: GestureConfig) {
            tvLabel.text = config.label

            val stroke = config.strokes.firstOrNull()
            tvCoords.text = if (stroke != null) {
                "(${stroke.startX.toInt()}, ${stroke.startY.toInt()})  →  " +
                        "(${stroke.endX.toInt()}, ${stroke.endY.toInt()})"
            } else {
                "No swipe defined"
            }

            tvMode.text = when (config.mode) {
                ExecutionMode.SINGLE -> "Single"
                ExecutionMode.LOOP   -> "Loop every ${config.loopIntervalMs}ms"
                ExecutionMode.BURST  -> "Burst ×${config.burstCount}"
            }

            btnEdit.setOnClickListener  { onEdit(config) }
            btnDel.setOnClickListener   { onDelete(config) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<GestureConfig>() {
            override fun areItemsTheSame(a: GestureConfig, b: GestureConfig) = a.id == b.id
            override fun areContentsTheSame(a: GestureConfig, b: GestureConfig) = a == b
        }
    }
}
